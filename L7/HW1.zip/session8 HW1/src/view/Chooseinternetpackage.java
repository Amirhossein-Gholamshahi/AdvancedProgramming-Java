package view;

import model.Internetmodel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import static view.Login.usertext1;
import static view.Login.passwordtext;



public class Chooseinternetpackage  {

  public static JFrame frame;
  public  static JPanel panel;
  public  static JLabel lable;
    public static JTextField usertext2;
    public static JButton button1;
    public static JButton button2;
    public static JButton button3;
    public static JButton button4;
    public static JButton button5;


    public void main() {
        JPanel panel=new JPanel();
        JFrame frame=new JFrame();
        frame.setSize(400,250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        panel.setLayout(null);
        frame.setTitle("Internet package  ");

        lable = new JLabel("Choose internet package ");
        lable.setBounds(10, 20, 180, 25);
        panel.add(lable);


        button1 = new JButton("2GB-1000 toman");
        button1.setBounds(10, 60, 150, 25);
        button1.setBackground(Color.red);
        button1.setForeground(Color.BLACK);
        panel.add(button1);
        button1.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Internetmodel internetmodel = null;
                try {
                    internetmodel = new Internetmodel().convertDBtoentity(usertext1.getText(),passwordtext.getText());
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                System.out.print("Cunrrent paybill: ");
                System.out.println(internetmodel.getPaybill()+1000);
                System.out.print("Current teraffic: ");
                System.out.println(internetmodel.getInternetteraffic()+2);

            }
        });





        button2 = new JButton("4GB-2000 toman");
        button2.setBounds(170, 60, 150, 25);
        button2.setBackground(Color.orange);
        button2.setForeground(Color.BLACK);
        panel.add(button2);
        button2.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));



        button3 = new JButton("10GB-5000 toman");
        button3.setBounds(10, 100, 150, 25);
        button3.setBackground(Color.yellow);
        button3.setForeground(Color.BLACK);
        panel.add(button3);
        button3.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));

        button4 = new JButton("25GB-10000 toman");
        button4.setBounds(170, 100, 150, 25);
        button4.setBackground(Color.green);
        button4.setForeground(Color.BLACK);
        panel.add(button4);
        button4.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));

        button5 = new JButton("submit");
        button5.setBounds(95, 140, 150, 25);
        button5.setBackground(Color.gray);
        button5.setForeground(Color.BLACK);
        panel.add(button5);
        button5.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));





        frame.setVisible(true);
    }
    public Chooseinternetpackage(){
        main();
    }



    }

