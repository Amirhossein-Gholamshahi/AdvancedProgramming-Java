package model;

import java.sql.*;

import static view.Login.passwordtext;
import static view.Login.usertext1;

public class Internetmodel {
    private String username;
    private String password;
    private int paybill;
    private int internetteraffic;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPaybill() {
        return paybill;
    }

    public void setPaybill(int paybill) {
        this.paybill = paybill;
    }

    public int getInternetteraffic() {
        return internetteraffic;
    }

    public void setInternetteraffic(int internetteraffic) {
        this.internetteraffic = internetteraffic;
    }
    public Internetmodel convertDBtoentity  (String username,String password)throws SQLException {
        Connection connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
        String SQL="select * from netHW1 where username= '"+username+"' and password= '"+password+"' ";
        Statement st = connection.createStatement();
        ResultSet rs=st.executeQuery(SQL);
    Internetmodel internetmodel1=new Internetmodel();
    internetmodel1.setUsername(usertext1.getText());
    internetmodel1.setPassword(passwordtext.getText());
    String sql1="select PAYBill from netHW1 where username= '"+usertext1.getText()+"' and password= '"+passwordtext.getText()+"' ";
    String sql2= "select INTERNETTERAFFIC from netHW1 where username= '"+usertext1.getText()+"' and password= '"+passwordtext.getText()+"' ";
        Statement st1 = connection.createStatement();
        Statement st2=connection.createStatement();
        ResultSet rs1=st1.executeQuery(sql1);
        ResultSet rs2=st2.executeQuery(sql2);
       if(rs1.next()&& rs2.next()){
           int paybill=rs1.getInt("PAYBILL");
           int internetteraffic=rs2.getInt("INTERNETTERAFFIC");
       }

    return internetmodel1;
    }


}
