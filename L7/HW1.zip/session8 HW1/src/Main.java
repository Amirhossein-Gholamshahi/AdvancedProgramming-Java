import controller.Internetctrl;
import model.Internetmodel;
import view.Chooseinternetpackage;
import view.Login;

public class Main {
    public static void main(String[] args) throws Exception {
        Internetmodel model=new Internetmodel();
        Login loginview=new Login();
        Internetctrl internetctrl=new Internetctrl(model,loginview);



    }
}
