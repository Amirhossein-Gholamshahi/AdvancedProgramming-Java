package controller;
import model.Internetmodel;
import view.Chooseinternetpackage;
import view.Login;

import javax.swing.plaf.basic.BasicMenuUI;
import java.sql.*;

import static view.Login.usertext1;
import static view.Login.passwordtext;

public class Internetctrl {
    private Internetmodel model;
    private Login loginviewl;
    private Chooseinternetpackage chooseinternetpackageview;

    public Internetctrl(Internetmodel model, Login loginviewl) {
        this.model = model;
        this.loginviewl = loginviewl;
    }
    public Internetctrl(){}

    public Internetctrl(Internetmodel model, Chooseinternetpackage chooseinternetpackageview) {
        this.model = model;
        this.chooseinternetpackageview = chooseinternetpackageview;
    }


    public void validatelogin(Internetmodel internetmodel) throws SQLException {
        Connection connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
        String SQL="select * from netHW1 where username= '"+usertext1.getText()+"' and password= '"+passwordtext.getText()+"' ";
        Statement st = connection.createStatement();
        ResultSet rs=st.executeQuery(SQL);
        if(rs.next()){
            System.out.println("Login successful");
            Chooseinternetpackage chooseinternetpackage=new Chooseinternetpackage();
        }else {
            System.out.println("Username or password is incorrect!");
        }
}}

