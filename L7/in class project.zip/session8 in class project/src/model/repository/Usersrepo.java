package model.repository;
import model.entity.Usersenti;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


    public class Usersrepo implements AutoCloseable{
        //public class PersonRepo {
        private Connection connection;
        private PreparedStatement preparedStatement;

        public Usersrepo() throws Exception{
            Class.forName ("oracle.jdbc.driver.OracleDriver");
            connection= DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
            connection.setAutoCommit (false);
        }

        public void insert(Usersenti usersenti) throws Exception{
            preparedStatement=connection.prepareStatement ("INSERT INTO hw2users(name ,username ,password ,email) VALUES (?,?,?,?)");
            preparedStatement.setString (1,usersenti.getName());
            preparedStatement.setString (2,usersenti.getUsername());
            preparedStatement.setString (3,usersenti.getPassword());
            preparedStatement.setString (4,usersenti.getEmail());

            preparedStatement.executeUpdate ();
        }

        public void update (Usersenti usersenti) throws Exception{
            preparedStatement=connection.prepareStatement ("UPDATE hw2users  SET username =?, password=?,email=? WHERE name=? ");
            preparedStatement.setString (1,usersenti.getUsername ());
            preparedStatement.setString (2,usersenti.getPassword ());
            preparedStatement.setString (3,usersenti.getEmail ());
            preparedStatement.setString (4,usersenti.getName ());
            preparedStatement.executeUpdate ();
        }

        public void delete(Usersenti usersenti) throws Exception{
            preparedStatement=connection.prepareStatement ("DELETE * FROM  hw2users WHERE name=?");
            preparedStatement.setString (1,usersenti.getName());
            preparedStatement.executeUpdate ();
        }

        public List<Usersenti> select() throws Exception{
            preparedStatement=connection.prepareStatement ("SELECT * FROM hw2users");
            ResultSet resultSet=preparedStatement.executeQuery ();
            List<Usersenti> usersentiList=new ArrayList <> ();
            while (resultSet.next ()){
                Usersenti usersenti=new Usersenti (); // call by reference
                usersenti.setName (resultSet.getString ("name"));
                usersenti.setUsername (resultSet.getString ("username"));
                usersenti.setPassword (resultSet.getString ("password"));
                usersenti.setEmail (resultSet.getString ("email"));
                usersentiList.add(usersenti);
            }
            return usersentiList;
        }
        public void commit() throws Exception{
            connection.commit ();
        }
        public void rollback() throws Exception{
            connection.rollback ();
        }
        public void close() throws Exception{
            preparedStatement.close ();
            connection.close ();

    }

}
