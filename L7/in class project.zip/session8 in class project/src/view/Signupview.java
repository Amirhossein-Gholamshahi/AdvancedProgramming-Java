package view;

import model.entity.Usersenti;
import model.repository.Usersrepo;
import model.service.Usersserv;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Signupview implements ActionListener {

    Usersenti usersenti=new Usersenti();
    public static JLabel plable;
    public static JLabel nlable;
    public static JLabel uslable;
    public static JLabel elable;

    public static JTextField usertext1;
    public static JTextField usertext2;
    public static JTextField usertext3;
    public static JPasswordField passwordtext;


    public static JButton button;
    public static JPanel panel;
    public static JFrame frame;

    public  void main() throws Exception{


        panel =new JPanel();
        frame = new JFrame();
        frame.setSize(400,250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);
        panel.setLayout(null);
        nlable =new JLabel("Name:");
        nlable.setBounds(10,20,80,25);
        panel.add(nlable);
        usertext1 = new JTextField(20);
        usertext1.setBounds(100,20,165,25);
        panel.add(usertext1);

        uslable =new JLabel("Username:");
        uslable.setBounds(10,50,80,25);
        panel.add(uslable);
        usertext2 = new JTextField(20);
        usertext2.setBounds(100,50,165,25);
        panel.add(usertext2);

        plable =new JLabel("Password:");
        plable.setBounds(10,80,80,25);
        panel.add(plable);
        passwordtext =new JPasswordField();
        passwordtext.setBounds(100,80,165,25);
        panel.add(passwordtext);

        elable =new JLabel("Email:");
        elable.setBounds(10,110,110,25);
        panel.add(elable);
        usertext3 = new JTextField(20);
        usertext3.setBounds(100,110,165,25);
        panel.add(usertext3);









        button = new JButton("Signup");
        button.setBounds(140,150,80,25);
        button.setBackground(Color.GRAY);
        button.setForeground(Color.BLACK);
        panel.add(button);
        button.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(this);




            frame.setVisible(true);













    }
    public Signupview()throws Exception{
        main();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        usersenti.setName(usertext1.getText());
        usersenti.setUsername(usertext2.getText());
        usersenti.setPassword(passwordtext.getText());
        usersenti.setEmail(usertext3.getText());
        try {
            Usersserv.getInstance().save(usersenti);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            Thread.sleep(2000);
        }catch (InterruptedException c){
            System.out.println("Program interrupted!");
        }

        try {
            Loginview loginview=new Loginview();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
