package view;

import model.Saipamodel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Saipaview {
    public static JLabel plable;
    public static JLabel nlable;
    public static JLabel uslable;
    public static JLabel elable;
    public static JLabel slable;
    public static JButton button;
    public static JPanel panel;
    public static JFrame frame;
    public static JTextField usertext1;
    public Saipaview(){
        main();
    }

    public static void main() {



        panel = new JPanel();
        frame = new JFrame();
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);
        panel.setLayout(null);
        nlable = new JLabel("Select the car you want to buy :");
        nlable.setBounds(10, 20, 180, 25);
        panel.add(nlable);



        button = new JButton("Pride 111");
        button.setBounds(10, 50, 100, 25);
        button.setBackground(Color.GREEN);
        button.setForeground(Color.BLACK);
        panel.add(button);
        button.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        final int[] number = {2202};
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                number[0] = number[0] += 1;
                System.out.println("You bought pride 111");
                Connection connection = null;
                try {
                    connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                    String SQL="update saipaco set numbersold='"+ number[0] +"'where name='pride 111'  ";
                    String sql="commit";
                    Statement st = connection.createStatement();
                    ResultSet rs=st.executeQuery(SQL);
                    Statement st1 = connection.createStatement();
                    ResultSet rs1=st1.executeQuery(sql);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }


            }
        });

        button = new JButton("Pride 131");
        button.setBounds(120, 50, 100, 25);
        button.setBackground(Color.GREEN);
        button.setForeground(Color.BLACK);
        panel.add(button);
        button.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));

        final int[] number1 = {1750};
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                number1[0] = number1[0] += 1;
                System.out.println("You bought pride 131");
                Connection connection = null;
                try {
                    connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                    String SQL="update saipaco set numbersold='"+ number1[0] +"'where name='pride 131'  ";
                    String sql="commit";
                    Statement st = connection.createStatement();
                    ResultSet rs=st.executeQuery(SQL);
                    Statement st1 = connection.createStatement();
                    ResultSet rs1=st1.executeQuery(sql);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }


            }
        });



        button = new JButton("Shahin");
        button.setBounds(10, 80, 100, 25);
        button.setBackground(Color.GREEN);
        button.setForeground(Color.BLACK);
        panel.add(button);
        button.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));

        final int[] number2 = {2201};
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                number2[0] = number2[0] += 1;
                System.out.println("You bought  shahin");
                Connection connection = null;
                try {
                    connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                    String SQL="update saipaco set numbersold='"+ number2[0] +"'where name='shahin'  ";
                    String sql="commit";
                    Statement st = connection.createStatement();
                    ResultSet rs=st.executeQuery(SQL);
                    Statement st1 = connection.createStatement();
                    ResultSet rs1=st1.executeQuery(sql);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }


            }
        });


        button = new JButton("Tiba2");
        button.setBounds(120, 80, 100, 25);
        button.setBackground(Color.GREEN);
        button.setForeground(Color.BLACK);
        panel.add(button);
        button.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        final int[] number3 = {8900};
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                number3[0] = number3[0] += 1;
                System.out.println("You bought  tiba2");
                Connection connection = null;
                try {
                    connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                    String SQL="update saipaco set numbersold='"+ number3[0] +"'where name='tiba2'  ";
                    String sql="commit";
                    Statement st = connection.createStatement();
                    ResultSet rs=st.executeQuery(SQL);
                    Statement st1 = connection.createStatement();
                    ResultSet rs1=st1.executeQuery(sql);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }


            }
        });





        frame.setVisible(true);

    }}
