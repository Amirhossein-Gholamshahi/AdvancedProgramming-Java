package model;

import view.Saipaview;

import java.sql.*;

public class Saipamodel {
    private String name;
    private int fee;
    private int numbersold;

    public Saipamodel(String name, int fee, int numbersold) {
        this.name = name;
        this.fee = fee;
        this.numbersold = numbersold;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFee() {
        return fee;
    }

    public void setFee(int fee) {
        this.fee = fee;
    }

    public int getNumbersold() {
        return numbersold;
    }

    public void setNumbersold(int numbersold) {
        this.numbersold = numbersold;
    }
     Saipaview saipaview=new Saipaview();




}