import model.Saipamodel;
import view.Saipaview;

import java.sql.*;

public class Main {
    public static void main(String[] args) {
        Saipamodel pride111=new Saipamodel("pride111",200,5000);
        Saipamodel pride131=new Saipamodel("pride131",185,1750);
        Saipamodel tiba2=new Saipamodel("tiba2",145,8900);
        Saipamodel shahin=new Saipamodel("shahin",450,2201);




    }
    }

