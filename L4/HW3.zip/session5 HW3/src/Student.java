public class Student <NAME,STUDENTID,FATHERSNAME> implements Cloneable{
    private NAME name;
    private STUDENTID studentid;
    private FATHERSNAME fathersname;

    public NAME getName() {
        return name;
    }

    public void setName(NAME name) {
        this.name = name;
    }

    public STUDENTID getStudentid() {
        return studentid;
    }

    public void setStudentid(STUDENTID studentid) {
        this.studentid = studentid;
    }

    public FATHERSNAME getFathersname() {
        return fathersname;
    }

    public void setFathersname(FATHERSNAME fathersname) {
        this.fathersname = fathersname;
    }
}
