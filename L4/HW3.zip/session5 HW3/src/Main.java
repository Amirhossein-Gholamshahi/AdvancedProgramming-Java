import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        Student student=new Student();
        System.out.println("Enter your name: ");
        student.setName(scan.nextLine());
        System.out.println("Enter your ID: ");
        student.setStudentid(scan.nextLine());
        System.out.println("Enter your fathers name: ");
        student.setFathersname(scan.nextLine());
        System.out.println("Enter your scores(5): ");
        List<Double> scoreslist=new ArrayList<>();
        for(int i=0;i<5;i++){
            scoreslist.add(scan.nextDouble());
        }
        System.out.println("Your scores are: "+scoreslist);
    }
}
