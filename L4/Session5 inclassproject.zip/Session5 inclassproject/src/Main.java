public class Main {
    public static void main(String[] args) {
        User user=new User();
        user.setName("Ali");
        user.setFamily("Mohtashami");
        user.setAge(20);
        user.setUsername("Ali4569");
        user.setJob("student");
        user.setPassword("al1moh155565");
        System.out.println("Users info :");
        System.out.println("Name: "+user.getName());
        System.out.println("Family: "+user.getFamily());
        System.out.println("Age: "+user.getAge());
        System.out.println("Username: "+user.getUsername());
        System.out.println("Job: "+user.getJob());
        System.out.println("Password: "+user.getPassword());

    }
}
