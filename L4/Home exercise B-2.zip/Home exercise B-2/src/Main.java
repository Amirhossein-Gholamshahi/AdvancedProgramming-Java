import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.print("Enter text: ");
        String text = scan.nextLine();
        System.out.println("Converted text is: ");
        sort(text);

    }
    public static void sort(String text){
        //prints the input elements in descending order
        TreeSet<Character> set=new TreeSet<Character>();
        char[] chararry= text.toCharArray();
        for(int i=0;i<chararry.length;i++){
            set.add(chararry[i]);
        }
        Iterator<Character> itr=set.iterator();
        while(itr.hasNext()){
            System.out.print(itr.next());
        }

    }
}
