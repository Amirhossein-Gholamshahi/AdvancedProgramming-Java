import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your name: ");
        String name=scan.nextLine();
        System.out.println("Enter your student ID: ");
        String studentID= scan.nextLine();
        System.out.println("Enter your average score: ");
        Double averagescore=scan.nextDouble();
        Map map=new HashMap<>();
        map.put("name",name);
        map.put("studentID",studentID);
        map.put("averagescore",averagescore);
        System.out.println("Your name is : "+map.get("name"));
        System.out.println("Your student ID is: "+map.get("studentID"));
        System.out.println("Your average score is: "+map.get("averagescore"));

    }
}
