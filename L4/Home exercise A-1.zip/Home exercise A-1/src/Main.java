import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        //Home Exercise A-1
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter names(Exit with 1): ");
        Set<String> set=new HashSet<String>();
        for(int i=0;i<1000;i++){
            set.add(scan.nextLine());
            if(set.contains("1")){
                break;
            }
        }
        set.remove("1");
        System.out.println("You entered these names(Duplicates are eliminated): ");
        for(String s:set){
            System.out.println(s);
        }
        System.out.println("Enter the name you want to search for: ");
        String name= scan.nextLine();
        if(set.contains(name)){
            System.out.println(name+" was found.");
        }else {
            System.out.println(name+" was not found!");
        }}}
