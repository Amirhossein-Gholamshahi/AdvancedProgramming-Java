import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner scan=new Scanner(System.in);
        User user=new User();
        System.out.println("Enter your name: ");
        user.setName(scan.nextLine());
        System.out.println("Enter your age: ");
        user.setAge(scan.nextLine());
        System.out.println("Before cloning: ");
        System.out.println("Your name is "+user.getName()+" and you are "+user.getAge()+" years old.");
        User user1=new User();
        User user2=new User();
        User user3=new User();
        try {
            user1=(User)user.clone();
            user2=(User)user.clone();
            user3=(User)user.clone();

        }
        catch (CloneNotSupportedException e){
            System.out.println("Clone not supported!");
        }
        System.out.println("After cloning: ");
        System.out.println("Main user -->"+user.getName()+","+user.getAge()+" id: "+user);
        System.out.println("Cloned user1 -->"+user1.getName()+","+user1.getAge()+" id: "+user1);
        System.out.println("Cloned user2 -->"+user2.getName()+","+user2.getAge()+" id: "+user2);
        System.out.println("Cloned user3 -->"+user3.getName()+","+user3.getAge()+" id: "+user3);



    }
}
