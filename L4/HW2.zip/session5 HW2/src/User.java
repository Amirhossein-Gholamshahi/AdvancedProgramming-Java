public class User<NAME,AGE> implements Cloneable{
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    private NAME name;
    private AGE age;

    public NAME getName() {
        return name;
    }

    public void setName(NAME name) {
        this.name = name;
    }

    public AGE getAge() {
        return age;
    }

    public void setAge(AGE age) {
        this.age = age;
    }
}
