
public class Location {
    public int row;
    public int column;
    public double maxvalue;
    public Location(int row,int column){
        this.row=row;
        this.column=column;
        System.out.println("("+row+","+column+")");
    }


}
