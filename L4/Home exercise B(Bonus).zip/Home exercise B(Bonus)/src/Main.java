import java.util.Scanner;

public class Main {
    public int maxvalue;
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter number of rows: ");
        int rows= scan.nextInt();
        System.out.println("Enter number of columns: ");
        int columns= scan.nextInt();
        System.out.println("Enter "+rows*columns+" elements: ");
        double[][] array = new double[rows][columns];
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                array[i][j]=scan.nextDouble();
            }
        }
        System.out.println("Given array is: ");
        for (int i = 0; i < array.length; i++){
            for (int j = 0; j < array[i].length; j++){
                System.out.print(array[i][j]);
                System.out.print(" , ");
            }
            System.out.println();
        }
        System.out.print("The index of largest number is : ");
        locatelargest(array);

    }
    public static Location locatelargest(double[][] array) {
        int i;
        int j = 0;
        int k=0;
        int z=0;
        double maxvalue = 0;
        maxvalue = array[0][0];
        for (i = 0; i <array.length; i++) {
            for (j = 0; j <array[i].length; j++) {
                if (array[i][j] > maxvalue) {
                    maxvalue = array[i][j];
                    k=i;
                    z=j;
                }
            }
        }
        Location location = new Location(k, z);
        return location;}
}
