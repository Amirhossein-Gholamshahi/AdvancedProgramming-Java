import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        //Home exercise A-2
        Scanner scan=new Scanner(System.in);
        Set<Integer> numset=new HashSet<Integer>();
        System.out.println("Enter a number:  ");
        int num= scan.nextInt();
        boolean isprime = true;
        for (int i = 2; i <= num / 2; ++i) {
            if (num % i == 0) {
                isprime =false;
                break;
            }
        }

        if (isprime){
            System.out.println(num + " is a prime number.");}
        else{
            System.out.println(num + " is not a prime number.");}
        if(!isprime) {
            for (int i = 2; i < num; i++) {
                while (num % i == 0) {
                    numset.add(i);
                    num = num / i;
                }
            }
            if (num > 2) {
                numset.add(num);
            }
            System.out.print("Prime factors of your given number is: ");
            System.out.println(numset);
        }

    }
}

