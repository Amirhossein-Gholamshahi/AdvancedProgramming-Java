public class Rectangle {
    public int length;
    public int width;
    public int Area;
    public int Perimeter;
    public Rectangle(){}
    public Rectangle(int length,int width){
        this.length=length;
        this.width=width;
        Area=length*width;
        Perimeter=(length+width)*2;
    }
    public void area(){
        System.out.println("Area of your defined rectangle is : "+Area);
    }
    public void perimeter(){
        System.out.println("Perimeter of your defined rectangle is : "+Perimeter);
    }
}
