public class Square {
    public int side;
    public int Area;
    public int Perimeter;
    public Square(){}
    public Square(int side){
        this.side=side;
        Area=side*side;
        Perimeter=side*4;
    }
    public void area (){
        System.out.println("Area of your defined square is : "+Area);
    }
    public void perimeter(){
        System.out.println("Perimeter of your defined square is : "+Perimeter);
    }

}
