import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Which shape do you want to define?(Enter 1 for square and 2 for rectangle): ");
        int shape =scan.nextInt();
        if(shape==1){
        System.out.println("Enter the value of squares side: ");
        Square square=new Square(scan.nextInt());
        square.area();
        square.perimeter();
    }
        else if(shape==2){
            System.out.println("Enter the length of the rectangle: ");
            int length= scan.nextInt();
            System.out.println("Enter the width of the rectangle: ");
            int width= scan.nextInt();
            Rectangle rectangle=new Rectangle(length,width);
            rectangle.area();
            rectangle.perimeter();

        }
        else {
            System.out.println("Invalid number!");
        }
}}
