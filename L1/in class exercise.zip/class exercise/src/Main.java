public class Main {
    public static void main(String[] args) {
    Book book=new Book("Lord of the rings","stephen king",593);
        System.out.println("Today: ");
    book.getbooksformlibrary();
        System.out.println("Next week: ");
    book.givebooksbacktothelibrary();
    }
}
