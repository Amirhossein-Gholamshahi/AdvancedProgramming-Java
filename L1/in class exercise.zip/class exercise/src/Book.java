public class Book {
    public String bookname;
    public String author;
    public int pages;
    public Book(){}
    public Book(String bookname,String author,int pages){
        this.bookname=bookname;
        this.pages=pages;
        this.author=author;
        System.out.println(bookname+" is written by "+author+" and it has "+pages);
    }
    public void getbooksformlibrary(){
        System.out.println("You borrowed "+ bookname+" form library");
    }
    public void givebooksbacktothelibrary(){
        System.out.println("You gave "+bookname+" back to the library! ");
    }
}
