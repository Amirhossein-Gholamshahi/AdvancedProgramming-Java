public class Equation {
    //ax+by=c a is x factor,b is y factor;c is constant value
    public String equation;
    public double xfactor;
    public double yfactor;
    public double constant;
    public Equation(){}
    public Equation(double xfactor,double yfactor,double constant){
        this.xfactor=xfactor;
        this.yfactor=yfactor;
        this.constant=constant;
        if(yfactor<0) {
            equation = (xfactor + "x" + yfactor + "y" + "=" + constant);
            System.out.println(equation);
        }
        else{
            equation = (xfactor + "x+" + yfactor + "y" + "=" + constant);
            System.out.println(equation);
        }
    }


}
