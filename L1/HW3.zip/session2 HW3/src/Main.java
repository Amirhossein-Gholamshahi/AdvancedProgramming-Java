import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter elements for first equation(suppose ax+by=c , a is x factor,b is y factor;c is constant value)");
        System.out.println("Xfactor: ");
        double eq1xfactor =scan.nextDouble();
        System.out.println("Yfactor: ");
        double eq1yfactor=scan.nextDouble();
        System.out.println("constant value: ");
        double eq1constant=scan.nextDouble();
        System.out.println("Enter elements for second equation");
        System.out.println("Xfactor: ");
        double eq2xfactor =scan.nextDouble();
        System.out.println("Yfactor: ");
        double eq2yfactor=scan.nextDouble();
        System.out.println("constant value: ");
        double eq2constant=scan.nextDouble();
        Equation equation1=new Equation(eq1xfactor,eq1yfactor,eq1constant);
        Equation equation2=new Equation(eq2xfactor,eq1yfactor,eq2constant);
        for(int i=0;i<1;i++){
            if((equation1.xfactor==0&&equation1.yfactor==0)||(equation2.xfactor==0&&equation2.yfactor==0)){
                System.out.println("Problem cannot be solved !");
                break;
            }
            else {
                double x= (equation1.constant*equation2.yfactor- equation1.yfactor*equation2.constant)/(equation1.xfactor*equation2.yfactor-equation1.yfactor* equation2.xfactor);
                double y=(equation1.xfactor* equation2.constant-equation1.constant* equation2.xfactor)/(equation1.xfactor* equation2.yfactor-equation1.yfactor* equation2.xfactor);
                System.out.println("Problem solved successfully");
                System.out.println("x: "+x);
                System.out.println("y: "+y);

            }
        }



    }


}
