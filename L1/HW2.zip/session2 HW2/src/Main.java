import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Hello user,please Enter your name : ");
        String name=scan.nextLine();
        System.out.println("Enter number of your scores: ");
        int length = scan.nextInt();
        System.out.println("Enter your scores : ");
        double[] scores = new double[length];
        for (int i = 0; i < length; i++) {
            scores[i] = scan.nextDouble();
        }

        System.out.println();
        System.out.println("Enter factors for each score: ");
        double[] factors = new double[length];
        for (int i = 0; i < length; i++) {
            factors[i] = scan.nextDouble();
        }
        System.out.println("Your scores and factors of each are shown below(every score has the factor number which is below that): ");
        for (int i = 0; i < length; i++) {
            System.out.print(scores[i] + " ,");
        }
        System.out.println();
        for (int i = 0; i < length; i++) {
            System.out.print(factors[i] + " ,");
        }
        System.out.println();
        double sum = 0;
        double sumf=0;
        for (int j = 0; j < length; j++) {
            sum = sum + scores[j] * factors[j];
                    sumf=sumf+factors[j];
        }
        double averagescore=sum/sumf;
        Student student=new Student(name,averagescore);


    }
}
