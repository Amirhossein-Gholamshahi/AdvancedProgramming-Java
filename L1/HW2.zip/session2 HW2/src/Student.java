public class Student {
    public String name;
    public double averagescore;
    public Student(){}
    public Student(String name,double averagescore){
        this.name=name;
        this.averagescore=averagescore;
        if(averagescore>=12){
            System.out.println(name+" passed with the average score of "+averagescore);
        }else{
            System.out.println(name+" failed with the average score of "+averagescore);
        }

    }

}
