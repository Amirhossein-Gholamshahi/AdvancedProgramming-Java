import java.util.Scanner;

public class Main {
    public static void main(String[] args)  {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter a string: ");
        String str=scan.nextLine();
        try {
            IsDigit(str);
            throw new NumberfoundException();
        }
        catch (NumberfoundException e){
            System.out.println(e.getMessage());
            e.printStackTrace();
        }



    }
    public static void IsDigit(String str) throws NumberfoundException {
        if(str.contains("1")||str.contains("2")||str.contains("3")||str.contains("4")||str.contains("5")||str.contains("6")
        ||str.contains("7")||str.contains("8")||str.contains("9")||str.contains("0")){
            throw new NumberfoundException();
        }else {
            System.out.println(str.length());
        }

    }
}
