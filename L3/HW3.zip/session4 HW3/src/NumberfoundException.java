public class NumberfoundException extends Exception{
    public NumberfoundException(String msg){
        super(msg);
    }
    public NumberfoundException(){
        super("Numbers not allowed!");

    }
}


