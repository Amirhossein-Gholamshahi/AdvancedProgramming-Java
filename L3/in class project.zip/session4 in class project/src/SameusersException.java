public class SameusersException extends Exception{
    public SameusersException(){
        super("Same users!");
    }
    public SameusersException(String message){
     super(message);
    }
}
