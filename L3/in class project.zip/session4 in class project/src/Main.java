import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        User users[]=new User[2];
        for(int i=0;i<=1;i++){
        System.out.println("Enter your name: ");
        String username=scan.nextLine();
        System.out.println("Enter your family(lastname): ");
        String userfamily=scan.nextLine();
        System.out.println("Enter your age: ");
        String userage=scan.nextLine();
        users[i]=new User(username,userfamily,userage);
        }
        try {
            if(users[0].name.equals(users[1].name)&&users[0].family.equals(users[1].family)&&users[0].age.equals(users[1].age)){
              throw new SameusersException();
            }
            else {
                System.out.println("Users information are shown below:  ");
                System.out.println("---User1---");
                users[0].showinfo();
                System.out.println("------------------");
                System.out.println("---User2---");
                users[1].showinfo();
                System.out.print("------------------");
            }
        }
        catch (SameusersException e){
            System.out.println(e.getMessage());
        }
    }
}
