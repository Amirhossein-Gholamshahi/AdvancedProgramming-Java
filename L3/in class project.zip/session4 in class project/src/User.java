public class User {
        public String name;
        public String age;
        public String family;
        public User(){}
        public User(String name,String family,String age){
            this.name=name;
            this.age=age;
            this.family=family;
    }
    public void showinfo(){
        System.out.println("Name: "+name);
        System.out.println("Family: "+family);
        System.out.println("Age: "+age);
    }

}
