public class Quadraticequation {
    //ax^2+bx+c=0
    public double a;
    public double b;
    public double c;
    public double delta;
    public double root1;
    public double root2;
    public Quadraticequation(){}
    public Quadraticequation(double a,double b,double c){
        this.a=a;
        this.b=b;
        this.c=c;
        delta=(b*b)-(a*c*4);
        root1=(-b+Math.sqrt(delta))/(2*a);
        root1=(-b-Math.sqrt(delta))/(2*a);

    }
}
