public class NegativedeltaException extends Exception{
    public NegativedeltaException(){
        super("Delta is negative!There are no real roots ");
    }
    public NegativedeltaException(String message){
        super(message);
    }
}
