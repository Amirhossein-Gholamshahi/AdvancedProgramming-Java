import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Standard form of a quadratic equation is : ax^2+bx+c=0 ");
        System.out.println("Enter a: ");
        double a=scan.nextDouble();
        System.out.println("Enter b: ");
        double b=scan.nextDouble();
        System.out.println("Enter c: ");
        double c=scan.nextDouble();
        Quadraticequation quadraticequation=new Quadraticequation(a,b,c);
        try {
            if(quadraticequation.delta<0){
                throw new NegativedeltaException();
            }
            else {
                System.out.println("Root 1: "+quadraticequation.root1);
                System.out.println("root 2: "+quadraticequation.root2);
            }
        }
        catch (NegativedeltaException e){
            System.out.println(e.getMessage());
        }
    }
}
