public class WronginputException extends Exception{
    public WronginputException(){
        super("One of the inputs is wrong!Try again");
    }
    public WronginputException(String message){
        super(message);
    }
}
