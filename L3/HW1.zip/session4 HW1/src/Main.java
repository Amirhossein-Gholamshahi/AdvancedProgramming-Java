import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        Student student=new Student("Alireza Mossavi","Ali81","Ali-Mossi8100");
        System.out.println("Enter your name: ");
        String name=scan.nextLine();
        System.out.println("Enter your username: ");
        String username=scan.nextLine();
        System.out.println("Enter your password: ");
        String password=scan.nextLine();
        try {
            if(!student.name.equals(name)||!student.username.equals(username)||!student.password.equals(password)){
                throw new WronginputException();
            }
            else if(student.name.equals(name)||student.username.equals(username)||student.password.equals(password)){
                System.out.println("Login successful");
            }
        }
        catch (WronginputException e){
            System.out.println(e.getMessage());
        }





    }
}
