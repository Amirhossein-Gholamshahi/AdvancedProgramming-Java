import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Personnel code: ");
        String personnelcode=scan.nextLine();
        System.out.println("Name: ");
        String name=scan.nextLine();
        System.out.println("ID number: ");
        String idnumber=scan.nextLine();
        System.out.println("Father name: ");
        String fathername=scan.nextLine();
        System.out.println("Position: ");
        String position=scan.nextLine();
        System.out.println("Salary: ");
        String salary=scan.nextLine();
        System.out.println("Records: ");
        String records=scan.nextLine();
        try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "amir",
                "myjava123")) {
            Class.forName("oracle.jdbc.driver.OracleDriver");// for old versions of JDBC
            /* insert into DB */
            PreparedStatement preparedStatement1 =
                    connection.prepareStatement("insert into hw3personnel (personnelcode ,name ,idnumber ,fathername,position," +
                            "salary,records) " +
                            "values (?,?,?,?,?,?,?)");
            preparedStatement1.setString(1,personnelcode);
            preparedStatement1.setString(2, name);
            preparedStatement1.setString(3, idnumber);
            preparedStatement1.setString(4, fathername);
            preparedStatement1.setString(5, position);
            preparedStatement1.setString(6, salary);
            preparedStatement1.setString(7, records);
            System.out.println ("Insert into DB: "+preparedStatement1.executeUpdate());

            System.out.println("Enter the personnel code of the employee you want to delete: ");
            String personnelcodedelete= scan.nextLine();

            /*Delete from DB*/
            PreparedStatement preparedStatement3 = connection.prepareStatement("delete from hw3personnel where personnelcode=?");
            preparedStatement3.setString(1, personnelcodedelete);
            System.out.println ("Delete from DB: "+preparedStatement3.executeUpdate());




        } catch (ClassNotFoundException e)// if no lib files are added
        {
            System.out.println("DB Driver Not Exist!!");
        } catch (SQLException e)
        {
            System.out.println("DB ERROR " + e.getMessage());
        }


    }
}
