public class Employee {
    private String Personnelcode;
    private String name;
    private String IDnumber;
    private String fathername;
    private String position;
    private String salary;
    private String records;
    //create table hw3personnel (personnelcode number primary key,name varchar2(20),idnumber number,fathername varchar2(20),position varchar2(20),salary number,records varchar2(20))

}
