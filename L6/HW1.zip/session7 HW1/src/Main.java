import java.util.Scanner;
import java.sql.*;
public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your username: ");
        String username=scan.nextLine();
        System.out.println("Enter your password: ");
        String password=scan.nextLine();
        System.out.println("Enter your usercode: ");
        String usercode=scan.nextLine();
        System.out.println("Enter your email: ");
        String email=scan.nextLine();
        System.out.println("Enter your age: ");
        String age=scan.nextLine();
        System.out.println("Enter your education status: ");
        String education=scan.nextLine();
        System.out.println("----------------------------------------");



        try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "amir",
                "myjava123")) {
            Class.forName("oracle.jdbc.driver.OracleDriver");// for old versions of JDBC
            /* insert into DB */
            PreparedStatement preparedStatement1 =
                    connection.prepareStatement("insert into hw1users (username ,usercode ,email ,age ,password,education) " +
                            "values (?,?,?,?,?,?)");
            preparedStatement1.setString(1,username);
            preparedStatement1.setString(2, usercode);
            preparedStatement1.setString(3, email);
            preparedStatement1.setString(4, age);
            preparedStatement1.setString(5, password);
            preparedStatement1.setString(6, education);

            System.out.println ("Insert into DB: "+preparedStatement1.executeUpdate());


            //Update inside DB
            System.out.println("Select which users age you want to update by entering usercode: ");
            String usercodeup=scan.nextLine();
            System.out.println("Select which property you want to update(age,email,...): ");
            String propertyupdate=scan.nextLine();
            System.out.println("Enter the new value: ");
            String newvalue=scan.nextLine();

            PreparedStatement preparedStatement2 = connection.prepareStatement("update hw1users set " +
                    ""+propertyupdate+"='"+newvalue+"' where usercode='"+usercodeup+"' " );

            System.out.println ("Update inside DB: "+preparedStatement2.executeUpdate());

            /*Select from DB*/
            PreparedStatement preparedStatement4 = connection.prepareStatement("select * from hw1users ");
            ResultSet resultSet = preparedStatement4.executeQuery();
            System.out.println ("Select results are as follows:");
            while (resultSet.next()) {
                System.out.println("username : "+resultSet.getString("username"));
                System.out.println("usercode: "+resultSet.getString("usercode"));
                System.out.println("email: "+resultSet.getString("email"));
                System.out.println("age: "+resultSet.getString("age"));
                System.out.println("password: "+resultSet.getString("password"));
                System.out.println("education: "+resultSet.getString("education"));
            }


        } catch (ClassNotFoundException e)// if no lib files are added
        {
            System.out.println("DB Driver Not Exist!!");
        } catch (SQLException e)
        {
            System.out.println("DB ERROR " + e.getMessage());
        }
    }


}





