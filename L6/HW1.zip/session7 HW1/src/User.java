public class User {
    public String username;
    public String usercode;
    public String email;
    public String password;
    public String education;
    public String age;

    public User(String username, String usercode, String email, String password, String education, String age) {
        this.username = username;
        this.usercode = usercode;
        this.email = email;
        this.password = password;
        this.education = education;
        this.age = age;
    }

}
