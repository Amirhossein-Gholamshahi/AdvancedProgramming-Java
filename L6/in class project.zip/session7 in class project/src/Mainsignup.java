import java.sql.*;
import java.util.Scanner;

public class Mainsignup {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Sign up");
        System.out.println("Name: ");
        String name=scan.nextLine();
        System.out.println("Username: ");
        String username=scan.nextLine();
        System.out.println("Password: ");
        String password=scan.nextLine();
        System.out.println("Email: ");
        String email=scan.nextLine();
        System.out.print("Creating your account.");
        try {
            Thread.sleep(1500);
            System.out.print(".");
        }catch (InterruptedException e){
            System.out.println("Program interrupted! ");
        }
        try {
            Thread.sleep(1300);
            System.out.print(".");
        }catch (InterruptedException e){
            System.out.println("Program interrupted! ");
        }
        try {
            Thread.sleep(700);
            System.out.print(".");
        }catch (InterruptedException e){
            System.out.println("Program interrupted! ");
        }
        try {
            Thread.sleep(350);
            System.out.println(".");
        }catch (InterruptedException e){
            System.out.println("Program interrupted! ");
        }
        System.out.println("Sign up successful");
        try {
            Thread.sleep(1000);
        }catch (InterruptedException e){
            System.out.println("Program interrupted!");
        }


        try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "amir",
                "myjava123")) {
            Class.forName("oracle.jdbc.driver.OracleDriver");// for old versions of JDBC
            /* insert into DB */
            PreparedStatement preparedStatement1 =
                    connection.prepareStatement("insert into hw2users (name ,username ,password ,email) " +
                            "values (?,?,?,?)");
            preparedStatement1.setString(1,name);
            preparedStatement1.setString(2, username);
            preparedStatement1.setString(3, password);
            preparedStatement1.setString(4, email);

            System.out.println ("Insert into DB: "+preparedStatement1.executeUpdate());

        } catch (ClassNotFoundException e)// if no lib files are added
        {
            System.out.println("DB Driver Not Exist!!");
        } catch (SQLException e)
        {
            System.out.println("DB ERROR " + e.getMessage());
        }


    }
}
