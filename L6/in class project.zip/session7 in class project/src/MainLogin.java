import java.sql.*;
import java.util.Scanner;
public class MainLogin {
        public static void main(String[] args) {
            Scanner scan=new Scanner(System.in);
            System.out.println("Login");
            System.out.println("Username: ");
            String usernamelogin=scan.nextLine();
            System.out.println("Password: ");
            String passwordlogin=scan.nextLine();

            try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "amir",
                    "myjava123")) {
                Class.forName("oracle.jdbc.driver.OracleDriver");// for old versions of JDBC
                Statement st = connection.createStatement();
                String SQL="select * from hw2users where username= '"+usernamelogin+"' and password= '"+passwordlogin+"' ";

                ResultSet rs=st.executeQuery(SQL);
                if(rs.next()){
                    System.out.println("Login successful");
                }else {
                    System.out.println("Username of password is incorrect!");
                }
            } catch (ClassNotFoundException e)// if no lib files are added
            {
                System.out.println("DB Driver Not Exist!!");
            } catch (SQLException e)
            {
                System.out.println("DB ERROR " + e.getMessage());
            }







        }

}
