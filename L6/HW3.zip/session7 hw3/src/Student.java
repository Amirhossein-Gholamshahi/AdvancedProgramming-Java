public class Student {
    private String StudentID;
    private String name;
    private int yearofentry;
    private double averagescore;


    //create table hw3studnets (studentid varchar2(20),name varchar2(20),yearofentry number,averagescore varchar2(20));
}
