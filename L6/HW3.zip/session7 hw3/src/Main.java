import javax.sound.midi.Soundbank;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("StudentID: ");
        String studentid=scan.nextLine();
        System.out.println("Name: ");
        String name=scan.nextLine();
        System.out.println("Year of entry: ");
        String yearofentry=scan.nextLine();
        System.out.println("Average score: ");
        String averagescore=scan.nextLine();
        try (Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "amir",
                "myjava123")) {
            Class.forName("oracle.jdbc.driver.OracleDriver");// for old versions of JDBC
            /* insert into DB */
            PreparedStatement preparedStatement1 =
                    connection.prepareStatement("insert into hw3studnets (studentid ,name ,yearofentry ,averagescore) " +
                            "values (?,?,?,?)");
            preparedStatement1.setString(1,studentid);
            preparedStatement1.setString(2, name);
            preparedStatement1.setString(3,yearofentry);
            preparedStatement1.setString(4, averagescore);
            System.out.println ("Insert into DB: "+preparedStatement1.executeUpdate());

            System.out.println("Enter the studentID of the student you want to modify or update: ");
            String studentidupdate=scan.nextLine();
            System.out.println("Enter the name of property you want to update(name,year of entry or etc.): ");
            String propertyupdate=scan.nextLine();
            System.out.println("New value: ");
            String newvalue=scan.nextLine();


            /* Update inside DB */
            PreparedStatement preparedStatement2 = connection.prepareStatement("update hw3studnets set " +
                    ""+propertyupdate+"='"+newvalue+"' where studentid='"+studentidupdate+"' " );

            System.out.println ("Update inside DB: "+preparedStatement2.executeUpdate());


            System.out.println("Enter the studentID of the student you want to delete: ");
            String studentiddelete=scan.nextLine();

            /*Delete from DB*/
            PreparedStatement preparedStatement3 = connection.prepareStatement("delete from hw3studnets " +
                    "where studentid='" +studentiddelete+"'");
            System.out.println ("Delete from DB: "+preparedStatement3.executeUpdate());




        } catch (ClassNotFoundException e)// if no lib files are added
        {
            System.out.println("DB Driver Not Exist!!");
        } catch (SQLException e)
        {
            System.out.println("DB ERROR " + e.getMessage());
        }

    }
}
