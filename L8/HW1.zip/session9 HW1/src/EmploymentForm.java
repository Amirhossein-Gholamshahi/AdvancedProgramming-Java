import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class EmploymentForm {
    public static void main(String[] args) {

        JFrame frame=new JFrame();
        JPanel panel=new JPanel();
        panel.setLayout(null);
        frame.setSize(400,350);

        frame.add(panel);


        JLabel welcomelbl=new JLabel("Welcome ,please enter your information in the fields below");
        welcomelbl.setBounds(10,15,500,40);
        panel.add(welcomelbl);

        JLabel namelbl=new JLabel("Name: ");
        namelbl.setBounds(10, 20, 120, 25);
        panel.add(namelbl);
        JTextField nametxt=new JTextField();
        nametxt.setBounds(100, 20, 165, 25);
        panel.add(nametxt);

        JLabel agelbl=new JLabel("Age: ");
        namelbl.setBounds(10, 60, 120, 25);
        panel.add(agelbl);
        JTextField agetxt=new JTextField();
        nametxt.setBounds(100, 60, 165, 25);
        panel.add(agetxt);

        JLabel fathersnamelbl=new JLabel("Fathers name: ");
        fathersnamelbl.setBounds(10, 100, 120, 25);
        panel.add(fathersnamelbl);
        JTextField fathersnametxt=new JTextField();
        fathersnametxt.setBounds(100, 100, 165, 25);
        panel.add(fathersnametxt);

        JLabel occupationlbl=new JLabel("Occupation: ");
        occupationlbl.setBounds(10, 140, 120, 25);
        panel.add(occupationlbl);
        JTextField occupationtxt=new JTextField();
        occupationtxt.setBounds(100, 140, 165, 25);
        panel.add(occupationtxt);


        JLabel citylbl=new JLabel("City: ");
        citylbl.setBounds(10, 180, 120, 25);
        panel.add(citylbl);
        JTextField citytxt=new JTextField();
        citytxt.setBounds(100, 180, 165, 25);
        panel.add(citytxt);

        JLabel educationlbl=new JLabel("Education: ");
        educationlbl.setBounds(10, 220, 120, 25);
        panel.add(educationlbl);
        JTextField educationtxt=new JTextField();
        educationtxt.setBounds(100, 220, 165, 25);
        panel.add(educationtxt);

        JButton submitbtn=new JButton("Submit");
        submitbtn.setBounds(125,260,100,30);
        submitbtn.setBackground(Color.green);
        submitbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection connection = null;
                try {
                    connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                    PreparedStatement preparedStatement=connection.prepareStatement("INSERT INTO session9HW1(name ,fathersname ,occupation ,city,education) VALUES (?,?,?,?,?)");
                    preparedStatement.setString (1,nametxt.getText());
                    preparedStatement.setString (2,fathersnametxt.getText());
                    preparedStatement.setString (3,occupationtxt.getText());
                    preparedStatement.setString (4,citytxt.getText());
                    preparedStatement.setString (5,educationtxt.getText());
                    preparedStatement.executeUpdate ();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                try {
                    Thread.sleep(1500);
                }catch (InterruptedException c){
                    System.out.println("Program interrupted!");
                }
                System.out.println("Your info submitted");


            }
        });
        panel.add(submitbtn);






        frame.setVisible(true);
    }
}
