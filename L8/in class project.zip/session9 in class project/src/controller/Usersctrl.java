package controller;

import model.entity.Usersenti;
import model.repository.Usersrepo;
import model.service.Usersserv;
import view.Loginview;
import view.Signupview;

import javax.swing.*;
import java.sql.*;

import static view.Loginview.*;

public class Usersctrl {
    private Usersenti usersenti;
    private Usersserv usersserv;
    private Usersrepo usersrepo;
    private Loginview loginview;
    private Signupview signupview;

    public Usersctrl(){}
    public Usersctrl(Usersenti usersenti, Usersserv usersserv, Usersrepo usersrepo, Signupview signupview) {
        this.usersenti = usersenti;
        this.usersserv = usersserv;
        this.usersrepo = usersrepo;
        this.signupview = signupview;
    }

    public Usersctrl(Usersenti usersenti, Usersserv usersserv, Usersrepo usersrepo, Loginview loginview) {
        this.usersenti = usersenti;
        this.usersserv = usersserv;
        this.usersrepo = usersrepo;
        this.loginview = loginview;
    }
    public void validatelogin(Usersenti usersenti) throws SQLException {
        Connection connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
        String SQL="select * from hw2users where username= '"+usertext1.getText()+"' and password= '"+passwordtext.getText()+"' ";
        String SQL2="select name from hw2users where username= '"+usertext1.getText()+"' and password= '"+passwordtext.getText()+"' ";
        Statement st = connection.createStatement();
        ResultSet rs=st.executeQuery(SQL);
        Statement st2 = connection.createStatement();
        ResultSet rs2=st2.executeQuery(SQL2);
        if(rs.next()&&rs2.next()){
            System.out.println("Login successful");
            JOptionPane.showMessageDialog(frame,"Hello dear "+rs2.getString(1)+" welcome to your account");
        }else {
            System.out.println("Username or password is incorrect!");
        }


    }

}
