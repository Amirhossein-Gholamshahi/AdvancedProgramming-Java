import controller.Usersctrl;
import model.entity.Usersenti;
import model.repository.Usersrepo;
import model.service.Usersserv;
import view.Loginview;
import view.Signupview;

public class Main {
    public static void main(String[] args) throws Exception {
        Signupview signupview = new Signupview();


    }


}
