package model.service;

import model.entity.Usersenti;
import model.repository.Usersrepo;

import java.util.List;

public class Usersserv {
    private Usersserv () {
    }

    private static Usersserv usersserv = new Usersserv ();

    public static Usersserv getInstance () {
        return usersserv;
    }

    public void save (Usersenti usersenti) throws Exception {
        try (Usersrepo personRepo = new Usersrepo ()) {
            personRepo.insert (usersenti);
            personRepo.commit ();
        }
    }
    public void edit (Usersenti usersenti) throws Exception{
        try (Usersrepo usersrepo=new Usersrepo ()){
            usersrepo.update (usersenti);
            usersrepo.commit ();
        }
    }

    public void remove(Usersenti usersenti) throws Exception{
        try (Usersrepo usersrepo=new Usersrepo ()){
            usersrepo.delete (usersenti);
            usersrepo.commit();
        }
    }
    public List<Usersenti> report() throws Exception{
        List<Usersenti> personEntis;
        try (Usersrepo personRepo=new Usersrepo ()){
            personEntis=personRepo.select();
        }
        return personEntis;
    }

}


