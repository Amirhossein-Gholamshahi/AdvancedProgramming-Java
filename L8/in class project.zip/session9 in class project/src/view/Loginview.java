package view;

import controller.Usersctrl;
import model.entity.Usersenti;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Loginview implements ActionListener {


    public static JLabel plable;
    public static JLabel nlable;
    public static JLabel uslable;
    public static JLabel elable;
    public static JLabel slable;

    public static JTextField usertext1;
    public static JTextField usertext2;
    public static JTextField usertext3;
    public static JPasswordField passwordtext;


    public static JButton button;
    public static JPanel panel;
    public static JFrame frame;

    public void main() throws Exception {

        try {
            UIManager.setLookAndFeel ("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch(Exception j) {
            j.printStackTrace ();
        }

        panel = new JPanel();
        frame = new JFrame();
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);
        panel.setLayout(null);
        nlable = new JLabel("Username:");
        nlable.setBounds(10, 20, 80, 25);
        panel.add(nlable);
        usertext1 = new JTextField(20);
        usertext1.setBounds(100, 20, 165, 25);
        panel.add(usertext1);
        Usersenti usersenti=new Usersenti();



        plable = new JLabel("Password:");
        plable.setBounds(10, 50, 80, 25);
        panel.add(plable);
        passwordtext = new JPasswordField();
        passwordtext.setBounds(100, 50, 165, 25);
        panel.add(passwordtext);



        button = new JButton("Login");
        button.setBounds(140, 80, 80, 25);
        button.setBackground(Color.GREEN);
        button.setForeground(Color.BLACK);
        panel.add(button);
        button.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        button.addActionListener(this);




        frame.setVisible(true);


    }
    public Loginview() throws Exception {
        main();
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        Usersctrl usersctrl=new Usersctrl();
        Usersenti usersenti=new Usersenti();
        try {
            usersctrl.validatelogin(usersenti);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
