import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Loginview {
   public static JTextField usernametxt;
   public static JPasswordField passwordtxt;
   public Loginview(){

        try {
            UIManager.setLookAndFeel ("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch(Exception j) {
            j.printStackTrace ();
        }

        JPanel panel = new JPanel();
        JFrame frame = new JFrame();
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.add(panel);
        panel.setLayout(null);
        JLabel usernamelbl = new JLabel("Username  :");
        usernamelbl.setBounds(10, 20, 80, 25);
        panel.add(usernamelbl);
         usernametxt = new JTextField();
        usernametxt.setBounds(100, 20, 165, 25);
        panel.add(usernametxt);







        JLabel passwordlbl = new JLabel("Password  :");
        passwordlbl.setBounds(10, 50, 80, 25);
        panel.add(passwordlbl);
        passwordtxt = new JPasswordField();
        passwordtxt.setBounds(100, 50, 165, 25);
        panel.add(passwordtxt);






        JButton loginbtn = new JButton("Login");
        loginbtn.setBounds(140, 80, 80, 25);
        loginbtn.setBackground(Color.GREEN);
        loginbtn.setForeground(Color.BLACK);
        panel.add(loginbtn);
        loginbtn.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        frame.setVisible(true);
        loginbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                    String SQL="select * from hw2users where username= '"+usernametxt.getText()+"' and password= '"+passwordtxt.getText()+"' ";
                   Statement statement=connection.createStatement();
                   ResultSet resultSet=statement.executeQuery(SQL);
                    if(resultSet.next()){
                        System.out.println("Login successful");
                        Editview editview=new Editview();
                    }else {
                        JOptionPane.showMessageDialog(frame, "Username or password is incorrect!", "Error", JOptionPane.ERROR_MESSAGE);
                        System.out.println("Username or password is incorrect!");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

            }
        });





    }}
