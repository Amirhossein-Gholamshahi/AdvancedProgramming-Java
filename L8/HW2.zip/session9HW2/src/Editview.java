import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Editview {


    public Editview() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception j) {
            j.printStackTrace();
        }
        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        frame.setSize(400, 400);
        JLabel label = new JLabel("Select which you want to to update:  ");
        label.setBounds(10, 20, 250, 20);
        String s2[] = {"Name", "Username", "Password", "Email"};
        JComboBox jComboBox = new JComboBox(s2);
        jComboBox.setBounds(200, 20, 90, 20);
        frame.add(panel);
        panel.setLayout(null);
        panel.add(label);
        panel.add(jComboBox);

        JLabel newvaluelbl = new JLabel("Enter new value  :");
        newvaluelbl.setBounds(10, 50, 200, 25);
        panel.add(newvaluelbl);
        JTextField newvaluetxt = new JTextField();
        newvaluetxt.setBounds(120, 50, 165, 25);
        panel.add(newvaluetxt);


        JButton loginbtn = new JButton("Submit");
        loginbtn.setBounds(140, 85, 80, 25);
        loginbtn.setBackground(Color.GREEN);
        loginbtn.setForeground(Color.BLACK);
        panel.add(loginbtn);
        loginbtn.setCursor(new java.awt.Cursor(Cursor.HAND_CURSOR));
        frame.setVisible(true);
        loginbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(jComboBox.getSelectedItem().equals("Name")){
                    String SQL2="update hw2users set NAME='"+newvaluetxt.getText()+"' where USERNAME='"+Loginview.usernametxt.getText() +"'  and PASSWORD='"+ Loginview.passwordtxt.getText()+"' ";
                    Connection connection = null;
                    try {
                        connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                        Statement statement2=connection.createStatement();
                        ResultSet resultSet2=statement2.executeQuery(SQL2);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
            }if(jComboBox.getSelectedItem().equals("Username")){
                    String SQL3="update hw2users set USERNAME='"+newvaluetxt.getText()+"' where USERNAME='"+Loginview.usernametxt.getText() +"'  and PASSWORD='"+ Loginview.passwordtxt.getText()+"' ";
                    Connection connection = null;
                    try {
                        connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                        Statement statement3=connection.createStatement();
                        ResultSet resultSet3=statement3.executeQuery(SQL3);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }if(jComboBox.getSelectedItem().equals("Password")){
                    String SQL4="update hw2users set PASSWORD='"+newvaluetxt.getText()+"' where USERNAME='"+Loginview.usernametxt.getText() +"'  and PASSWORD='"+ Loginview.passwordtxt.getText()+"' ";
                    Connection connection = null;
                    try {
                        connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                        Statement statement4=connection.createStatement();
                        ResultSet resultSet4=statement4.executeQuery(SQL4);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }if(jComboBox.getSelectedItem().equals("Email")){
                    String SQL5="update hw2users set EMAIL='"+newvaluetxt.getText()+"' where USERNAME='"+Loginview.usernametxt.getText() +"'  and PASSWORD='"+ Loginview.passwordtxt.getText()+"' ";
                    Connection connection = null;
                    try {
                        connection = DriverManager.getConnection ("jdbc:oracle:thin:@localhost:1521:xe", "amir", "myjava123");
                        Statement statement5=connection.createStatement();
                        ResultSet resultSet5=statement5.executeQuery(SQL5);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }

        };


    });
    }}
