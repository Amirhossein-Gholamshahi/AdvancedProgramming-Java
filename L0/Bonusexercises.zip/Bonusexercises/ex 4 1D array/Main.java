package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //Bonus exercise 4(1D array)
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the number of your scores(how many scores you are gonna enter) : ");
        int num =scan.nextInt();
        System.out.println("Enter your scores: ");
        int [] scores=new int[num];
        for(int i=0;i<num;i++) {
            scores[i] = scan.nextInt();
        }
        System.out.println("Your scores are :");
        for(int i=0;i<scores.length;i++){
            System.out.println(scores[i]);
        }
    }

}