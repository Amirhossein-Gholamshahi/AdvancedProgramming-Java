package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// Bonus exercise 7(2D array)
        System.out.println("Enter the number of matrix rows: ");
        Scanner scan=new Scanner(System.in);
        int rows= scan.nextInt();
        System.out.println("Enter the number of matrix columns: ");
        int columns =scan.nextInt();
        System.out.println("Enter the elements of the matrix: ");
        int[][] mat=new int[rows][columns];
        for(int i=0;i<rows;i++){
            for(int j=0;j<columns;j++){
                mat[i][j]=scan.nextInt();
            }
        }
        System.out.println("Your matrix is : ");
        for(int i=0;i<rows;i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print(mat[i][j]);
                System.out.print(" , ");
            }
            System.out.println();
        }

    }
}
