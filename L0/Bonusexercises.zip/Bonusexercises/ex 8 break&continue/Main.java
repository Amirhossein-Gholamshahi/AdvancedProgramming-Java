package com.company;

public class Main {

    public static void main(String[] args) {
	//Bonus exercise 8(using continue and break)
        for(int i =1; i<=100; i++){
            if(i%7==0&&i%5==0&&i%2==0){
                break;
            }
            if(i%3==0){
                continue;
            }
            System.out.println(i);
        }
    }
}
