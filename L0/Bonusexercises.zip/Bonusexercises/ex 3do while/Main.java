package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //Bonus exercise(do while)
        Scanner s=new Scanner(System.in);
        System.out.println("Solve this math problem");
        System.out.println("12*5-5+17*2= ");
        int answer=12*5-5+17*2;
        int userinput=s.nextInt();
        do {
            System.out.println("Wrong answer!Try again");
            userinput=s.nextInt();
        }
        while (userinput!=answer);
        System.out.println("You won!");


    }
}
