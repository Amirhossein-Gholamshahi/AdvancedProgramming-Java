package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	//exercise 6(while loops)
        int i=1;
        while (i<=5){
            System.out.println("*");
            i++;

        }
    }
}
