package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// Bonus excercise 2(else if)
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter you height(centimeters): ");
        int height = scan.nextInt();
        if(height>=170){
            System.out.println("You are tall");
        }else if(height>=155&&height<=170){
            System.out.println("You are neither tall nor short");
        }else{
            System.out.println("You are short");
        }
    }
}
