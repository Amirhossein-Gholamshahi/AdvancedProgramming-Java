package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // problem 2(HW2)
        Scanner scan =new Scanner(System.in);
        System.out.println("Enter the number of elements : ");
        int length = scan.nextInt();
        int[] array = new int[length];
        System.out.println("Enter the elements : ");
        for(int i=0;i<length;i++){
            array[i]=scan.nextInt();
        }
        int maxnum=array[0];
        for(int i=0;i<length;i++){
            if(array[i]>maxnum){
                maxnum=array[i];
            }
        }
        System.out.println("The maximum number is " +maxnum);

    }
}
