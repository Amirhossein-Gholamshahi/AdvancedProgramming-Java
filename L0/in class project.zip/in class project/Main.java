package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan =new Scanner(System.in);
        System.out.println("Enter the number of elements : ");
        int length = scan.nextInt();
        int[] array = new int[length];
        System.out.println("Enter the elements : ");
        for(int i=0;i<length;i++){
            array[i]=scan.nextInt();
        }
        System.out.println("Enter the number which you want to search for: ");
        int target =scan.nextInt();
        searchfrequency(array,target);
    }
    public static void searchfrequency (int[] x,int keyword){
        System.out.println(search(x,keyword));
        frequency(x,keyword);

    }
    public static boolean search (int[] x,int keyword){
        for(int i=0;i<x.length;i++){
            if(x[i]==keyword){
                return true;
            }}
        return false;
    }
    public static void frequency (int[] x,int keyword){
        int c=0;
        for(int i=0;i<x.length;i++){
            if(x[i]==keyword){
                c++;
            }
        }
        if(c==0){
            System.out.println("The number you searched for ("+keyword+") didn't occur at all");
        }else {
            System.out.println("The number you searched for ("+keyword+") occured "+c+" times");

        }}






}

