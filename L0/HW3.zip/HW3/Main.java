package com.company;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        // problem 3(HW3)
        int result = 0;
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter first number : ");
        int num1=scan.nextInt();
        System.out.println("Enter second number : ");
        int num2=scan.nextInt();
        System.out.println("Enter the operand(It can be +,-,*,/)");
        char operand = scan.next().charAt(0);
        switch(operand){
            case '*':
                System.out.println(num1+"x"+num2+"="+num1*num2);
                break;
            case '+':
                System.out.println(num1+"+"+num2+"="+(num1+num2));
                break;
            case '-':
                if(num1>num2){
                    result=num1-num2;
                    System.out.println(num1 + "-" + num2 + "=" + result);
                }else if (num1<num2){
                    result=num2-num1;
                    System.out.println(num2 + "-" + num1 + "=" + result);
                }
                break;

            case '/':
                System.out.println(num1 + "/" + num2 + "=" + num1 / num2);
                break;
            default:
                System.out.println("You didn't enter a valid operand !");

        }}}
