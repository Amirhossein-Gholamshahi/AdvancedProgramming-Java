package com.company;

public class Main {

    public static void main(String[] args) {
        // problem 1(HW1)
        for(int i=1;i<=4;i++){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
