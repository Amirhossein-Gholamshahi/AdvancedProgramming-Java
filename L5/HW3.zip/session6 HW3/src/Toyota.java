public class Toyota extends Car {
    public Toyota(String model, double engineDisplacment, String gearbox,
                  double fuelconsumption, String bodytype, double maxtorque) {
        super(model, engineDisplacment, gearbox, fuelconsumption, bodytype, maxtorque);
    }
    public Toyota(){}

    @Override
    public String toString() {
        return "Info: (" +
                "model='" + model + '\'' +
                ", engineDisplacment=" + engineDisplacment +
                ", gearbox='" + gearbox + '\'' +
                ", fuelconsumption=" + fuelconsumption +
                ", bodytype='" + bodytype + '\'' +
                ", maxtorque=" + maxtorque +
                ')';
    }

}
