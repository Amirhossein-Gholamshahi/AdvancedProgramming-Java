public class Carfactory {
    public Car getInstance(String str) {
        if (str.equals("Volvo")){
            System.out.println("Volvo selected");
            return new Volvo("XC90",2000,"6speed-automatic"
                    ,18.5,"FullsizedSUV",35);}
        else if (str.equals("Toyota")){
            System.out.println("Toyota selected");
            return new Toyota("CHR",2700,
                    "4speedautomatic",14,"Crossover",255);}
        else if (str.equals("Bmw")){
            System.out.println("Bmw selected");
            return new Bmw("730Li",3500,
                    "10speedautomatic",20,"Fullsizedsedan",475);}
        else
            return null;
    }
}
