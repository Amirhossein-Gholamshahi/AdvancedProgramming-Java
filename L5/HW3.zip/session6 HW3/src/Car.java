public class Car {
    public String model;
    public double engineDisplacment;
    public String gearbox;
    public double fuelconsumption;
    public String bodytype;
    public double maxtorque;

    public Car(String model, double engineDisplacment, String gearbox,
               double fuelconsumption, String bodytype, double maxtorque) {
        this.model = model;
        this.engineDisplacment = engineDisplacment;
        this.gearbox = gearbox;
        this.fuelconsumption = fuelconsumption;
        this.bodytype = bodytype;
        this.maxtorque = maxtorque;
    }
    public Car(){}

}

