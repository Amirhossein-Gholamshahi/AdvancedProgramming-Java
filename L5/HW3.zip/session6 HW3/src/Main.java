import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter Brand name(Bmw,Toyota,Volvo): ");
        String brand=scan.nextLine();
        Carfactory cf=new Carfactory();
        Car obj=cf.getInstance(brand);
        System.out.print("Factory is creating a car");
        try{
            Thread.sleep(850);
        }catch (InterruptedException e){
            System.out.println("Program interrupted!");
        }
        System.out.print(".");
        try{
            Thread.sleep(780);
        }catch (InterruptedException e){
            System.out.println("Program interrupted!");
        }
        System.out.print(".");
        try{
            Thread.sleep(750);
        }catch (InterruptedException e){
            System.out.println("Program interrupted!");
        }
        System.out.print(".");
        try{
            Thread.sleep(700);
        }catch (InterruptedException e){
            System.out.println("Program interrupted!");
        }
        System.out.print(".");
        try{
            Thread.sleep(500);
        }catch (InterruptedException e){
            System.out.println("Program interrupted!");
        }
        System.out.print(".");
        try{
            Thread.sleep(400);
        }catch (InterruptedException e){
            System.out.println("Program interrupted!");
        }
        System.out.print(".");
        System.out.println();
        System.out.println(obj);
    }
}
