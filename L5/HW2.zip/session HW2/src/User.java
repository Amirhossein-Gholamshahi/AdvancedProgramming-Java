import java.util.Scanner;

public class User {
    Scanner scan=new Scanner(System.in);
    private static User user;
    public synchronized static User getUserInstance() {
        if (user == null){
            user = new User();
    }
        return user;
    }
    private User(){}
    public void inputinfo(){
        System.out.println("Name: ");
        String name= scan.nextLine();
        System.out.println("Age: ");
        String age=scan.nextLine();
        System.out.println("Country: ");
        String country=scan.nextLine();
        System.out.println("City: ");
        String city=scan.nextLine();
        System.out.println("Name: "+name+" ---- "+"Age: "+age+" ---- "+"Country: "+country+" ---- "+"City: "+city);
    }

}
