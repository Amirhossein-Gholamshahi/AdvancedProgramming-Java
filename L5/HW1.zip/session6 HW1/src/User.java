public class User {
    private String username;
    private String realname;
    private String password;
    private String address;
    private String phonenumber;
    private String age;
    private String education;

    public User(){}
    public User(String username, String realname, String password,
                String address, String phonenumber, String age, String education) {
        this.username = username;
        this.realname = realname;
        this.password = password;
        this.address=address;
        this.phonenumber = phonenumber;
        this.age = age;
        this.education = education;
    }

    }