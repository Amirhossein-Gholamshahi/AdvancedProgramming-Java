import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your info(Realname and age are mandatory):");
        System.out.println("Realname: ");
        String realname=scan.nextLine();
        System.out.println("Age: ");
        String age=scan.nextLine();
        System.out.println("Address: ");
        String address=scan.nextLine();
        System.out.println("Education: ");
        String education=scan.nextLine();
        UserBuilder user=new UserBuilder().setAddress(address)
        .setAge(age).setRealname(realname).setEducation(education);
        System.out.println("You are "+user.getRealname()+" and you are "+user.getAge()+" years old" );
        System.out.println(user.toString());


    }
}
