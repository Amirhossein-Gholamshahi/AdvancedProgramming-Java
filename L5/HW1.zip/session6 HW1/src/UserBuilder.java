public class UserBuilder {
    private String username;
    private String realname;
    private String password;
    private String address;
    private String phonenumber;
    private String age;
    private String education;

    @Override
    public String toString() {
        return "Info: {" +
                "username='" + username + '\'' +
                ", realname='" + realname + '\'' +
                ", password='" + password + '\'' +
                ", address='" + address + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                ", age=" + age +
                ", education='" + education + '\'' +
                '}';
    }

    public String getUsername() {
        return username;
    }

    public String getRealname() {
        return realname;
    }

    public String getPassword() {
        return password;
    }

    public String getAddress() {
        return address;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public String getAge() {
        return age;
    }

    public String getEducation() {
        return education;
    }

    public UserBuilder setUsername(String username) {
        this.username = username;
        return this;
    }

    public UserBuilder setRealname(String realname) {
        this.realname = realname;
        return this;
    }

    public UserBuilder setPassword(String password) {
        this.password = password;
        return this;
    }

    public UserBuilder setAddress(String address) {
        this.address = address;
        return this;
    }

    public UserBuilder setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
        return this;
    }

    public UserBuilder setAge(String age) {
        this.age = age;
        return this;
    }

    public UserBuilder setEducation(String education) {
        this.education = education;
        return this;
    }

    public User createUser() {
        return new User(username, realname, password, address, phonenumber, age, education);
    }
}