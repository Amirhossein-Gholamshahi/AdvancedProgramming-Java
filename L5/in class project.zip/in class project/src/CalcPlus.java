public class CalcPlus implements Calculate{

    @Override
    public double calc(double a, double b) {
        double result=a+b;
        System.out.println(a+"+"+b+"="+result);
        return result;
    }

}
