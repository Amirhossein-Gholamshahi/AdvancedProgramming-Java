public interface Calculate {
    public double calc(double a,double b);
}
