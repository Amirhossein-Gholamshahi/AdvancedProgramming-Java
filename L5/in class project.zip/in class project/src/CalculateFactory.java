
public class CalculateFactory {
    public Calculate getInstance(String str) {
        if (str.equals("-"))
            return new CalcMinus();
        else if (str.equals("+"))
            return new CalcPlus();
        else
            return null;

    }


}
