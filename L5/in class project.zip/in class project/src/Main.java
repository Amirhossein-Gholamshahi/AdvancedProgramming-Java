import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter what you want to calculate: ");
        String [] phrase=new String[3];
        for(int i=0;i<3;i++){
            phrase[i]= scan.next();
        }
        CalculateFactory cf=new CalculateFactory();
            Calculate obj=cf.getInstance(phrase[1]);
            double str1=Double.parseDouble(phrase[0]);
            double str2=Double.parseDouble(phrase[2]);

        obj.calc(str1,str2);



        }






    }

