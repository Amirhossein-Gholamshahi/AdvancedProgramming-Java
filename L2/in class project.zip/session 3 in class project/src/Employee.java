public  abstract class Employee {
    public abstract void role();
}
