public class Main {
    public static void main(String[] args) {
        Employee employee=new Employee() {
            @Override
            public void role() {
                System.out.println("Im employee");
            };
        };
        Teacher teacher = new Teacher() {
            @Override
            public void role() {
                System.out.println("Im teacher");
            }
        };
        Student student=new Student() {
            @Override
            public void role() {
                System.out.println("Im student");
            }
        };
        employee.role();
        student.role();
        teacher.role();

    }
}
