public abstract class Teacher {
    public abstract void role ();

}
