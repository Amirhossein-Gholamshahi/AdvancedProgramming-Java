public abstract class Student {
    public abstract void role ();
}
