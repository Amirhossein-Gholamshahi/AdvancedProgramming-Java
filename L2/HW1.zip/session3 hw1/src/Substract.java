public interface Substract {
    public double substract (double a,double b);
}
