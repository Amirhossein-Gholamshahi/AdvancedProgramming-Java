import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Operation operation = new Operation();
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter first number : ");
        double num1=scan.nextDouble();
        System.out.println("Enter second number : ");
        double num2=scan.nextDouble();
        System.out.println("Enter the operand(It can be +,-,*,/)");
        char operand = scan.next().charAt(0);
        switch(operand){
            case '*':
                System.out.println(operation.multiply(num1,num2));
                break;
            case '+':
                System.out.println(operation.add(num1,num2));
                break;
            case '-':
                if(num1>num2){
                    System.out.println(operation.substract(num1,num2));
                }else if (num1<num2){
                    System.out.println(operation.substract(num2,num1));
                }
                break;

            case '/':
                System.out.println(operation.divide(num1,num2));
                break;
            default:
                System.out.println("You didn't enter a valid operand !");

        }
    }

}
