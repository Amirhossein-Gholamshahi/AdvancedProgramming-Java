public interface Add {
    public double add (double a,double b);
}
