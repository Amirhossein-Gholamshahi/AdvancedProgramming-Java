public interface Multiply {
    public double multiply(double a, double b);
}
