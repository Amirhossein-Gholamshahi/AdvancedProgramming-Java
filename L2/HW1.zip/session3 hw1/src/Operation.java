public class Operation implements Add,Substract,Divide,Multiply {

    @Override
    public double add(double a, double b) {
        double result = a+b;
        return result;
    }

    @Override
    public double divide(double a, double b) {
        double result=a/b;
        return result;
    }

    @Override
    public double multiply(double a, double b) {
        double result=a*b;
        return 0;
    }

    @Override
    public double substract(double a, double b) {
        double result=a-b;
        return result;
    }}



