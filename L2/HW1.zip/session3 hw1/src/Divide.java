public interface Divide {
    public double divide (double a, double b);
}
