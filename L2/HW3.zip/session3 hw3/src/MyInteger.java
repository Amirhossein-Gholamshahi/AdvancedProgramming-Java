public interface MyInteger {
   public void IsEven(int a);
   public void IsOdd(int a);
   public void IsPosetive(int a);
   public void IsNegative(int a);
   public void IsZero(int a);
}
