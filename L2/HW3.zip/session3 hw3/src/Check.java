public class Check implements MyInteger{
    public Check(){}
    public int a;

    @Override
    public void IsEven(int a) {
        if(a%2==0){
            System.out.println("This number is Even");
        }else{
            System.out.println("This number is not Even");
        }
    }

    @Override
    public void IsOdd(int a) {
       if(a%2!=0){
           System.out.println("This number is Odd");
       }else{
           System.out.println("This number is not  Odd");
       }
    }

    @Override
    public void IsPosetive(int a) {
        if(a>0){
            System.out.println("This number is posetive");
        }else{
            System.out.println("This number is not posetive");
        }

    }

    @Override
    public void IsNegative(int a) {
        if(a<0){
            System.out.println("This number is Negative");
        }else{
            System.out.println("This number is not negative");
        }

    }

    @Override
    public void IsZero(int a) {
        if(a==0){
            System.out.println("The number is zero");
        }else{
            System.out.println("The number is not zero ");
        }

    }
}
