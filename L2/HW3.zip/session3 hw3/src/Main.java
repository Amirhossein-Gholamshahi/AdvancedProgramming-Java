import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter a number :");
        int a=scan.nextInt();
    Check check=new Check();
    check.IsEven(a);
    check.IsOdd(a);
    check.IsPosetive(a);
    check.IsNegative(a);
    check.IsZero(a);
    }
}
