import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("enter name : ");
        String name=scan.nextLine();
        Dars dars=new Dars();
        System.out.print("hamniaz: ");
        dars.hamniaz(name);
        System.out.print("pishniaz: ");
        dars.pishniaz(name);
        System.out.println("tedad vahed: ");
        dars.vahed(name);
    }
}
