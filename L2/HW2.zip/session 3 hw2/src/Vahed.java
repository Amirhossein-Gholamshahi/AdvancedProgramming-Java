public interface Vahed {
    void vahed(String name);
}
