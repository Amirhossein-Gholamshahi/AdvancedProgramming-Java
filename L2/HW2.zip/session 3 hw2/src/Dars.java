public class Dars implements pishniaz,hamniaz,Vahed {
    public String name;

    @Override
    public void hamniaz(String a) {
        if(a.equals("fizik2")){
        System.out.println("riazi2");
    }else if(a.equals("sakhteman haye gosaste")){
            System.out.println("----");}
    }

    @Override
    public void pishniaz(String a) {
        if(a.equals("fizik2")){
            System.out.println("fizik1");
        }else if(a.equals("sakhteman haye gosaste")){
            System.out.println("riazi1,mabani computer");}
    }

    @Override
    public void vahed(String a) {
        if(a.equals("fizik2")){
            System.out.println("3");
        }else if(a.equals("sakhteman haye gosaste")){
            System.out.println("2");}
    }
}
