public interface pishniaz {
     void pishniaz(String a);

}
