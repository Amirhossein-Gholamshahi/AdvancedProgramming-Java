public interface hamniaz {
    void hamniaz(String a);
}
